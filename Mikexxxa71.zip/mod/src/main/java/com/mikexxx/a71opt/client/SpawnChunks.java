package com.mikexxx.a71opt.client;

import com.mikexxx.a71opt.A71Config;
import com.mikexxx.a71opt.A71Optimizer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerChunkCache;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.TicketType;
import net.minecraft.util.Unit;
import net.minecraft.world.level.ChunkPos;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Vanilla 1.20.1 haelt um den Welt-Spawn der Oberwelt dauerhaft einen riesigen Bereich geladen
 * (Ticket-Radius 11). Dieser Bereich wird mitgetickt, belegt RAM und muss beim Speichern
 * (z.B. beim Oeffnen des Pausenmenues) komplett serialisiert werden.
 *
 * Hier wird das Spawn-Ticket nach dem Start durch ein kleineres ersetzt. Die Chunks werden danach
 * ueber die normalen Tick-Budgets entladen und gespeichert, nichts geht verloren.
 */
@Mod.EventBusSubscriber(modid = A71Optimizer.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class SpawnChunks {

    /** Radius, den Vanilla in MinecraftServer.prepareLevels und ServerLevel.setDefaultSpawnPos benutzt. */
    private static final int VANILLA_RADIUS = 11;

    private SpawnChunks() {
    }

    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent event) {
        if (!A71Config.ENABLED.get() || !A71Config.SHRINK_SPAWN_CHUNKS.get()) {
            return;
        }
        shrink(event.getServer());
    }

    /** Muss auf dem Server-Thread laufen (Event und /a71 spawn sorgen dafuer). */
    static void shrink(MinecraftServer server) {
        try {
            int radius = A71Config.SPAWN_CHUNK_RADIUS.get();
            if (radius >= VANILLA_RADIUS) {
                return;
            }
            ServerLevel level = server.overworld();
            ServerChunkCache cache = level.getChunkSource();
            ChunkPos spawn = new ChunkPos(level.getSharedSpawnPos());
            cache.removeRegionTicket(TicketType.START, spawn, VANILLA_RADIUS, Unit.INSTANCE);
            if (radius > 0) {
                cache.addRegionTicket(TicketType.START, spawn, radius, Unit.INSTANCE);
            }
            A71Optimizer.LOGGER.info("[A71] Spawn-Chunks: Radius {} -> {} (Chunk {}, {})",
                    VANILLA_RADIUS, radius, spawn.x, spawn.z);
        } catch (Throwable t) {
            A71Optimizer.LOGGER.error("[A71] Spawn-Chunks konnten nicht verkleinert werden", t);
        }
    }
}
