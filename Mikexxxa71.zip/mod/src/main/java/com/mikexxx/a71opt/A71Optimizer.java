package com.mikexxx.a71opt;

import com.mojang.logging.LogUtils;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import org.slf4j.Logger;

/**
 * Mikexxx A71 Optimizer - reine Client-Mod fuer Forge 1.20.1.
 * Die eigentliche Arbeit steckt in den Klassen im Paket "client".
 */
@Mod(A71Optimizer.MODID)
public class A71Optimizer {

    public static final String MODID = "mikexxx_a71opt";
    public static final Logger LOGGER = LogUtils.getLogger();

    public A71Optimizer() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, A71Config.SPEC);
        LOGGER.info("[A71] Mikexxx A71 Optimizer geladen");
    }
}
