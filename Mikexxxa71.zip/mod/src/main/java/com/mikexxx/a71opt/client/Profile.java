package com.mikexxx.a71opt.client;

import com.mikexxx.a71opt.A71Config;
import com.mikexxx.a71opt.A71Optimizer;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.GraphicsStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.Options;
import net.minecraft.client.ParticleStatus;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Das A71-Profil: setzt einmalig die Grafik-Optionen, die auf Adreno 618 + LTW + Shader am meisten bringen.
 * Jede Option wird einzeln gesetzt, ein Fehler bei einer Option stoppt die anderen nicht.
 */
final class Profile {

    private static final String MARKER = "mikexxx_a71opt.profil-angewendet";

    private Profile() {
    }

    private static Path markerPath() {
        return FMLPaths.CONFIGDIR.get().resolve(MARKER);
    }

    static boolean wasApplied() {
        return Files.exists(markerPath());
    }

    static void markApplied() {
        try {
            Files.writeString(markerPath(),
                    "A71-Profil wurde angewendet. Diese Datei loeschen, um es beim naechsten Start erneut anzuwenden.\n",
                    StandardCharsets.UTF_8);
        } catch (IOException e) {
            A71Optimizer.LOGGER.warn("[A71] Marker-Datei konnte nicht geschrieben werden", e);
        }
    }

    static void apply(Minecraft mc) {
        Options o = mc.options;

        set("Renderdistanz", o.renderDistance(), A71Config.PROFILE_RENDER_DISTANCE.get());
        set("Simulationsdistanz", o.simulationDistance(), A71Config.PROFILE_SIMULATION_DISTANCE.get());
        set("Max FPS", o.framerateLimit(), A71Config.PROFILE_MAX_FPS.get());

        if (A71Config.PROFILE_FAST_GRAPHICS.get()) {
            set("Grafik", o.graphicsMode(), GraphicsStatus.FAST);
        }
        if (A71Config.PROFILE_FEWER_PARTICLES.get()) {
            set("Partikel", o.particles(), ParticleStatus.DECREASED);
        }
        if (A71Config.PROFILE_NO_CLOUDS.get()) {
            set("Wolken", o.cloudStatus(), CloudStatus.OFF);
        }
        if (A71Config.PROFILE_NO_ENTITY_SHADOWS.get()) {
            set("Entity-Schatten", o.entityShadows(), Boolean.FALSE);
        }
        if (A71Config.PROFILE_SHORT_ENTITY_DISTANCE.get()) {
            set("Entity-Sichtweite", o.entityDistanceScaling(), Double.valueOf(0.5D));
        }
        if (A71Config.PROFILE_LOW_BIOME_BLEND.get()) {
            set("Biom-Uebergang", o.biomeBlendRadius(), Integer.valueOf(1));
        }

        try {
            o.save();
        } catch (Throwable t) {
            A71Optimizer.LOGGER.warn("[A71] options.txt konnte nicht gespeichert werden", t);
        }
        A71Optimizer.LOGGER.info("[A71] A71-Profil angewendet");
    }

    private static <T> void set(String name, OptionInstance<T> option, T value) {
        try {
            option.set(value);
        } catch (Throwable t) {
            A71Optimizer.LOGGER.warn("[A71] Option '{}' konnte nicht gesetzt werden", name, t);
        }
    }
}
